import argparse
import torch
from torch.utils.data import DataLoader
from dataset import PIIDataset, collate_batch
from model import create_model
from torch.optim import AdamW
from transformers import AutoTokenizer
from labels import LABELS
from tqdm import tqdm


def train_loop(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0
    for batch in tqdm(dataloader):
        optimizer.zero_grad()

        input_ids = torch.tensor(batch["input_ids"]).to(device)
        attention_mask = torch.tensor(batch["attention_mask"]).to(device)
        labels = torch.tensor(batch["labels"]).to(device)

        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels
        )

        loss = outputs.loss
        loss.backward()
        optimizer.step()
        total_loss += loss.item()

    return total_loss / len(dataloader)


def eval_loop(model, dataloader, device):
    model.eval()
    total_loss = 0
    with torch.no_grad():
        for batch in tqdm(dataloader):
            input_ids = torch.tensor(batch["input_ids"]).to(device)
            attention_mask = torch.tensor(batch["attention_mask"]).to(device)
            labels = torch.tensor(batch["labels"]).to(device)

            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels
            )

            loss = outputs.loss
            total_loss += loss.item()

    return total_loss / len(dataloader)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", required=True)
    parser.add_argument("--train", required=True)
    parser.add_argument("--dev", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=5e-5)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()

    device = torch.device(args.device)

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)

    # LABELS from labels.py
    label_list = LABELS

    # Load datasets
    train_dataset = PIIDataset(args.train, tokenizer, label_list, is_train=True)
    dev_dataset = PIIDataset(args.dev, tokenizer, label_list, is_train=False)

    # DataLoaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=lambda b: collate_batch(b, tokenizer.pad_token_id)
    )

    dev_loader = DataLoader(
        dev_dataset,
        batch_size=args.batch_size,
        collate_fn=lambda b: collate_batch(b, tokenizer.pad_token_id)
    )

    # Model
    model = create_model(args.model_name)
    model.to(device)

    optimizer = AdamW(model.parameters(), lr=args.lr)

    # Train
    for epoch in range(args.epochs):
        print(f"Epoch {epoch + 1}/{args.epochs}")
        train_loss = train_loop(model, train_loader, optimizer, device)
        print(f"Epoch {epoch + 1} Loss: {train_loss:.4f}")

    # Evaluate
    dev_loss = eval_loop(model, dev_loader, device)
    print(f"Dev Loss: {dev_loss:.4f}")

    # Save model and tokenizer
    model.model.save_pretrained(args.out_dir)
    tokenizer.save_pretrained(args.out_dir)

    print("Model saved to:", args.out_dir)


if __name__ == "__main__":
    main()
