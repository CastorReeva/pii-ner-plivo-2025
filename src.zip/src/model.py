from transformers import AutoModelForTokenClassification
from labels import LABEL2ID, ID2LABEL
import torch.nn as nn


class DistilBERTForNER(nn.Module):
    def __init__(self, model_name):
        super().__init__()
        # Load base DistilBERT model
        self.model = AutoModelForTokenClassification.from_pretrained(
            model_name,
            num_labels=len(LABEL2ID),
            id2label=ID2LABEL,
            label2id=LABEL2ID,
        )
        
        # Extra dropout for better generalization
        self.dropout = nn.Dropout(0.1)
        
    def forward(self, **kwargs):
        outputs = self.model(**kwargs)
        
        if "logits" in outputs:
            outputs.logits = self.dropout(outputs.logits)
        
        return outputs


def create_model(model_name: str):
    """
    Factory function used by train.py and predict.py
    """
    return DistilBERTForNER(model_name)
