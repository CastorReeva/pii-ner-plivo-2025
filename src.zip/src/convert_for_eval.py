import json
import argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        preds = json.load(f)

    out = []
    for uid, ents in preds.items():
        converted = []
        for e in ents:
            converted.append({
                "start": e["start"],
                "end": e["end"],
                "label": e["label"]
            })
        out.append({
            "id": uid,
            "entities": converted
        })

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    print(f"Wrote evaluator-compatible file: {args.output}")

if __name__ == "__main__":
    main()
